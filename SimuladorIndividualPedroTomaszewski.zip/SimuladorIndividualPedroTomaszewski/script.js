function calculaDados () {
    var setores = Number(qtdSetor.value)
    var rendaIngressos = Number(vendasIngresso.value)
    var rendaParcerias = Number(rendaParceria.value)

    var qtdKits = setores * 2

    porcentagemIngresso = rendaIngressos * 1.10
    porcentagemParceria = rendaParcerias * 1.30

    mensagem1.innerHTML = `Com nosso projeto, você irá precisar de no mínimo ${qtdKits} kits de sensores em seu estádio,
        sendo ${setores} kits por setor`

    mensagem2.innerHTML = `Com nosso projeto, você irá lucrar R$${porcentagemIngresso.toFixed(2)} (10%) em vendas com ingressos e R$${porcentagemParceria.toFixed(2)} (30%) em parcerias`
}